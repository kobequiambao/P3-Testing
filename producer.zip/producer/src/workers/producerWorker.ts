import { parentPort } from "worker_threads";
import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Resolve proto from project working directory so it works in both TS and built JS
// When running via npm scripts, CWD is the producer folder
const PROTO_PATH = path.resolve(process.cwd(), "proto/media.proto");

const packageDef = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const grpcObj = grpc.loadPackageDefinition(packageDef) as any;
const mediaPackage = grpcObj.media;

if (!parentPort) throw new Error("No parent port found");

interface WorkerMessage {
  threadId: number;
  videoFolder: string;
  consumerAddress: string;
}

async function uploadVideo(
  filename: string,
  filePath: string,
  client: any,
  threadId: number
): Promise<void> {
  return new Promise((resolve, reject) => {
    const call = client.upload((err: any, response: any) => {
      if (err) {
        parentPort!.postMessage(
          `❌ Upload error for ${filename}: ${err.message}`
        );
        reject(err);
      }
    });

    let responseReceived = false;

    call.on("data", (response: any) => {
      responseReceived = true;
      if (response.success) {
        parentPort!.postMessage(
          `✅ ${filename} | Queue: ${response.queue_length}`
        );
      } else if (response.is_duplicate) {
        parentPort!.postMessage(`🔄 ${filename} | Duplicate detected`);
      } else if (response.queue_full) {
        parentPort!.postMessage(`🔴 ${filename} | Queue FULL - DROPPED`);
      } else {
        parentPort!.postMessage(`❌ ${filename} | ${response.message}`);
      }
    });

    call.on("end", () => {
      if (!responseReceived) {
        parentPort!.postMessage(`⚠️  ${filename} | No response from server`);
      }
      resolve();
    });

    const fileStream = fs.createReadStream(filePath, {
      highWaterMark: 64 * 1024,
    });

    fileStream.on("data", (chunk) => {
      const writeSuccess = call.write({ filename, data: chunk });
      if (!writeSuccess) {
        fileStream.pause();
      }
    });

    call.on("drain", () => {
      fileStream.resume();
    });

    fileStream.on("end", () => {
      call.end();
    });

    fileStream.on("error", (err) => {
      parentPort!.postMessage(
        `File read error for ${filename}: ${err.message}`
      );
      call.cancel();
      reject(err);
    });
  });
}

parentPort.on("message", async (task: WorkerMessage) => {
  const { threadId, videoFolder, consumerAddress } = task;

  try {
    parentPort!.postMessage(`Initializing thread ${threadId}`);
    parentPort!.postMessage(`Consumer address: ${consumerAddress}`);
    parentPort!.postMessage(`Video folder: ${videoFolder}`);

    const client = new mediaPackage.MediaUpload(
      consumerAddress,
      grpc.credentials.createInsecure()
    );

    const files = fs.readdirSync(videoFolder);
    const videoFiles = files.filter((f) =>
      [".mp4", ".mkv", ".avi", ".webm"].includes(
        f.substring(f.lastIndexOf(".")).toLowerCase()
      )
    );

    if (videoFiles.length === 0) {
      parentPort!.postMessage(`No videos found in folder`);
      process.exit(0);
    }

    parentPort!.postMessage(`Found ${videoFiles.length} videos`);

    for (const videoFile of videoFiles) {
      const filePath = path.join(videoFolder, videoFile);
      parentPort!.postMessage(`Starting upload: ${videoFile}`);
      try {
        await uploadVideo(videoFile, filePath, client, threadId);
        parentPort!.postMessage(`Completed: ${videoFile}`);
      } catch (err: any) {
        parentPort!.postMessage(
          `Failed to upload ${videoFile}: ${err.message}`
        );
      }
    }

    parentPort!.postMessage(`All uploads completed`);
    process.exit(0);
  } catch (err: any) {
    parentPort!.postMessage(`Fatal error: ${err.message}`);
    process.exit(1);
  }
});
