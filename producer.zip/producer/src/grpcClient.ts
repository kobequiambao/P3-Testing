import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import fs from "fs";
import path from "path";
import { CONFIG } from "./config";

const PROTO_PATH = path.resolve(__dirname, "../proto/media.proto");

const packageDef = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const grpcObj = grpc.loadPackageDefinition(packageDef) as any;
const mediaPackage = grpcObj.media;

export function uploadVideo(filename: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const client = new mediaPackage.MediaUpload(
      CONFIG.CONSUMER_ADDRESS,
      grpc.credentials.createInsecure()
    );

    const call = client.upload((err: any, response: any) => {
      if (err) {
        console.error(`❌ Upload failed for ${filename}:`, err.message);
        reject(err);
      }
    });

    let isQueueFull = false;

    call.on("data", (response: any) => {
      if (response.queue_full) {
        console.warn(
          `⚠️  QUEUE FULL on consumer! (${response.queue_length}/${response.queue_length})`
        );
        isQueueFull = true;
      } else {
        isQueueFull = false;
      }

      if (response.is_duplicate) {
        console.warn(`🔄 Duplicate rejected: ${filename}`);
      }

      if (response.success) {
        console.log(`✅ ${filename} accepted`);
      } else {
        console.warn(`❌ ${filename} rejected | Reason: ${response.message}`);
      }
    });

    const filePath = path.join(CONFIG.VIDEO_FOLDER, filename);
    const fileStream = fs.createReadStream(filePath, {
      highWaterMark: 64 * 1024,
    });

    fileStream.on("data", (chunk) => {
      if (isQueueFull) {
        console.log("⏸️  Pausing upload - queue full on consumer");
        fileStream.pause();
        return;
      }

      const writeSuccess = call.write({ filename, data: chunk });
      if (!writeSuccess) {
        fileStream.pause();
      }
    });

    call.on("drain", () => {
      fileStream.resume();
    });

    fileStream.on("end", () => {
      call.end();
      console.log(`📤 Finished sending: ${filename}`);
      resolve();
    });

    fileStream.on("error", (err) => {
      console.error(`File read error for ${filename}:`, err.message);
      call.cancel();
      reject(err);
    });
  });
}
