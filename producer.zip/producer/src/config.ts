export const CONFIG = {
  CONSUMER_ADDRESS: "localhost:50051", // change later to actual IP of consumer
  VIDEO_FOLDER: "./videos",
};
