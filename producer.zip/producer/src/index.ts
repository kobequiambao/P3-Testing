import fs from "fs";
import path from "path";
import readline from "readline";
import { Worker } from "worker_threads";
import net from "net";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(query: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(query, resolve);
  });
}

interface ProducerConfig {
  p: number; // number of producer threads
  consumerAddress: string;
  videoFolders: string[];
}

async function getConfiguration(): Promise<ProducerConfig> {
  console.log("\n========================================");
  console.log("🎥 MEDIA UPLOAD SERVICE - PRODUCER");
  console.log("========================================\n");

  let p = 0;
  while (p <= 0) {
    const pInput = await question(
      "Enter number of producer threads (p) [default: 1]: "
    );
    p = pInput ? parseInt(pInput) : 1;
    if (p <= 0) {
      console.log("❌ Please enter a positive number");
    }
  }

  const consumerAddress = await question(
    "Enter consumer address [default: localhost:50051]: "
  );
  const address = consumerAddress || "localhost:50051";

  const videoFolders: string[] = [];

  for (let i = 0; i < p; i++) {
    const folderName = `videos_producer_${i + 1}`;
    const folderPath = path.resolve(__dirname, "..", "videos", folderName);

    if (!fs.existsSync(folderPath)) {
      console.log(`❌ Folder not found: ${folderPath}`);
      console.log(`   Please create folder: ${folderPath}`);
      process.exit(1);
    }

    videoFolders.push(folderPath);
  }

  rl.close();

  return { p, consumerAddress: address, videoFolders };
}

async function startProducerThreads(config: ProducerConfig) {
  console.log("\n========================================");
  console.log("Configuration:");
  console.log(`  Producer threads (p): ${config.p}`);
  console.log(`  Consumer address: ${config.consumerAddress}`);
  console.log("  Video folders:");
  config.videoFolders.forEach((folder, i) => {
    console.log(`    ${i + 1}. ${folder}`);
  });
  console.log("========================================\n");

  // Preflight: verify consumerAddress is reachable before spawning workers
  const [host, portStr] = config.consumerAddress.split(":");
  const port = Number(portStr || 50051);
  const reachable = await new Promise<boolean>((resolve) => {
    const socket = new net.Socket();
    const timeoutMs = 3000;
    const onDone = (ok: boolean) => {
      try {
        socket.destroy();
      } catch {}
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => onDone(true));
    socket.once("timeout", () => onDone(false));
    socket.once("error", () => onDone(false));
    socket.connect(port, host);
  });

  if (!reachable) {
    console.log(
      `❌ Cannot reach consumer at ${config.consumerAddress}.\n` +
        `   Check IP/port, firewall rules, and network connectivity.\n` +
        `   Tip: On producer run: Test-NetConnection -ComputerName ${host} -Port ${port}`
    );
    process.exit(1);
  }

  const producerWorkerPath = new URL(
    "./workers/producerWorker.js",
    import.meta.url
  );
  const workers: Worker[] = [];

  for (let i = 0; i < config.p; i++) {
    const worker = new Worker(producerWorkerPath);

    worker.postMessage({
      threadId: i + 1,
      videoFolder: config.videoFolders[i],
      consumerAddress: config.consumerAddress,
    });

    worker.on("message", (msg) => {
      console.log(`[Thread ${i + 1}] ${msg}`);
    });

    worker.on("error", (err) => {
      console.error(`[Thread ${i + 1}] Error:`, err.message);
    });

    worker.on("exit", (code) => {
      console.log(`[Thread ${i + 1}] Exited with code ${code}`);
    });

    workers.push(worker);
  }

  console.log("✅ All producer threads started\n");
  console.log("Waiting for uploads to complete...\n");
}

async function main() {
  const config = await getConfiguration();
  await startProducerThreads(config);
}

main();
