# P3-Networked-Producer-and-Consumer

A distributed media upload service with producer and consumer running on separate machines.

## Features

- ✅ Producer threads read from separate folders
- ✅ Consumer processes videos concurrently
- ✅ Leaky bucket queue design
- ✅ Duplicate detection
- ✅ Web GUI with video preview
- ✅ Real-time queue status
- ❌ Video Compression

---

## Local Setup (Same Machine)

### Step 1: Start Consumer

```bash
cd consumer
npm install
npm start
```

When prompted:
- Enter number of consumer threads (default: 1)
- Enter max queue length (default: 5)

**Output:**
```
📡 gRPC server running at 0.0.0.0:50051
🌐 Web GUI running at http://localhost:8080
```

### Step 2: View GUI

Open browser: `http://localhost:8080`

### Step 3: Start Producer

```bash
cd producer
npm install
npm start
```

When prompted:
- Enter number of producer threads
- Enter consumer address: **Press Enter** (default: `localhost:50051`)


---

## Two Devices Setup (Different Machines)

### Prerequisites

Both machines must be on the **same network** (WiFi/LAN).

### Step 1: Find Consumer's IP Address

**On the machine running Consumer:**

#### macOS
```bash
ifconfig | grep inet
```
Look for line like: `inet 192.168.1.50`

#### Windows
```bash
ipconfig
```
Look for: `IPv4 Address . . . . . . . . . : 192.168.1.100`

**Use this IP address** (e.g., `192.168.x.x`)

### Step 2: Start Consumer (First Machine)

```bash
cd consumer
npm install
npm start
```

When prompted:
- Enter number of consumer threads (default: 1)
- Enter max queue length (default: 5)

**Output:**
```
📡 gRPC server running at 0.0.0.0:50051
🌐 Web GUI running at http://localhost:8080
```

### Step 3: View GUI

Open browser on any device:
- **`http://<consumer-ip>:8080`**
- Example: `http://192.168.1.50:8080`

### Step 4: Start Producer (Second Machine)

```bash
cd producer
npm install
npm start
```

When prompted:
- Enter number of producer threads
- Enter consumer address: **`<consumer-ip>:50051`**
  - Example: `192.168.1.50:50051`

---


