export const CONFIG = {
  PORT: 50051,
  UPLOAD_FOLDER: "./uploads",
};
