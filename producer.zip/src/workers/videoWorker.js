import { parentPort } from "worker_threads";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!parentPort) throw new Error("No parent port found");

parentPort.on("message", async (task) => {
  try {
    const saveDir = path.resolve(__dirname, "../../videos");
    const savePath = path.join(saveDir, task.filename);

    if (!fs.existsSync(saveDir)) fs.mkdirSync(saveDir, { recursive: true });

    await fs.promises.writeFile(savePath, task.videoBuffer);

    parentPort.postMessage(`✅ Saved video: ${task.filename}`);
    parentPort.postMessage("done");
  } catch (err) {
    console.error("Error saving video:", err);
    parentPort.postMessage("done");
  }
});
