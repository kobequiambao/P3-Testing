import { UploadQueue } from "../queue/uploadQueue.ts";
export let globalQueue: UploadQueue;

import crypto from "crypto";

const seenHashes = new Set<string>();
let queue: UploadQueue;
let droppedCount = 0;

export function handleUpload(maxQueue: number, numWorkers: number = 1) {
  // Initialize queue with config
  queue = new UploadQueue(numWorkers, maxQueue);
  globalQueue = queue;

  return async function upload(call: any) {
    const chunks: Buffer[] = [];
    let filename = "upload_" + Date.now() + ".mp4";

    call.on("data", (chunk: any) => {
      if (chunk.filename) filename = chunk.filename;
      if (chunk.data) {
        chunks.push(Buffer.from(chunk.data));
      }
    });

    call.on("end", () => {
      const videoBuffer = Buffer.concat(chunks);
      const fileHash = crypto
        .createHash("sha256")
        .update(videoBuffer)
        .digest("hex");

      const maxQueueLength = queue.getMaxQueueLength();
      const currentQueueLength = queue.getQueueLength();

      // Check duplicate
      if (seenHashes.has(fileHash)) {
        console.warn(
          `⚠️  Duplicate detected: ${filename} (hash: ${fileHash.substring(
            0,
            8
          )}...)`
        );
        call.write({
          success: false,
          message: "Duplicate video rejected!",
          queue_length: currentQueueLength,
          queue_full: false,
          hash: fileHash,
          is_duplicate: true,
        });
        call.end();
        return;
      }

      // Check queue full
      if (currentQueueLength >= maxQueueLength) {
        console.warn(
          `🔴 Queue FULL (${currentQueueLength}/${maxQueueLength}). Dropping: ${filename}`
        );
        droppedCount++;
        call.write({
          success: false,
          message: "Queue full - video dropped!",
          queue_length: currentQueueLength,
          queue_full: true,
          hash: fileHash,
          is_duplicate: false,
        });
        call.end();
        return;
      }

      // Accept video
      seenHashes.add(fileHash);
      queue.addTask({ videoBuffer, filename });

      console.log(
        `✅ Video accepted: ${filename} | Queue: ${
          currentQueueLength + 1
        }/${maxQueueLength}`
      );

      call.write({
        success: true,
        message: "Video queued successfully!",
        queue_length: currentQueueLength + 1,
        queue_full: false,
        hash: fileHash,
        is_duplicate: false,
      });

      call.end();
    });

    call.on("error", (err: any) => {
      console.error("gRPC call error:", err);
    });
  };
}

export function getQueueStatus(maxQueue: number, numWorkers: number = 1) {
  if (!queue) {
    queue = new UploadQueue(1, maxQueue);
  }

  return function status(call: any, callback: any) {
    const queueLength = queue.getQueueLength();
    const maxQueueLength = queue.getMaxQueueLength();

    callback(null, {
      current_length: queueLength,
      max_length: maxQueueLength,
      is_full: queueLength >= maxQueueLength,
      videos_dropped: queue.getDroppedCount(),
    });
  };
}

export function getDroppedCount(): number {
  return droppedCount;
}
