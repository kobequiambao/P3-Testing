import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import readline from "readline";
import { CONFIG } from "./config.ts";
import {
  handleUpload,
  getQueueStatus,
  globalQueue,
  getDroppedCount,
} from "./handlers/uploadHandlers.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PROTO_PATH = path.resolve(__dirname, "../proto/media.proto");
const packageDef = protoLoader.loadSync(PROTO_PATH);
const mediaProto = grpc.loadPackageDefinition(packageDef).media as any;

interface ServerConfig {
  c: number; // consumer threads / workers
  q: number; // max queue length
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(query: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(query, resolve);
  });
}

async function getConfiguration(): Promise<ServerConfig> {
  console.log("\n========================================");
  console.log("🎬 MEDIA UPLOAD SERVICE - CONSUMER");
  console.log("========================================\n");

  let c = 0;
  let q = 0;

  while (c <= 0) {
    const cInput = await question(
      "Enter number of consumer threads (c) [default: 1]: "
    );
    c = cInput ? parseInt(cInput) : 1;
    if (c <= 0) {
      console.log("❌ Please enter a positive number");
    }
  }

  while (q <= 0) {
    const qInput = await question("Enter max queue length (q) [default: 5]: ");
    q = qInput ? parseInt(qInput) : 5;
    if (q <= 0) {
      console.log("❌ Please enter a positive number");
    }
  }

  rl.close();

  return { c, q };
}

async function startGrpcServer(config: ServerConfig) {
  const server = new grpc.Server();
  const uploadHandler = handleUpload(config.q, config.c);
  const statusHandler = getQueueStatus(config.q, config.c);

  server.addService(mediaProto.MediaUpload.service, {
    upload: uploadHandler,
    getQueueStatus: statusHandler,
  });

  server.bindAsync(
    `0.0.0.0:${CONFIG.PORT}`,
    grpc.ServerCredentials.createInsecure(),
    (err, port) => {
      if (err) throw err;
      console.log(`\n📡 gRPC server running at 0.0.0.0:${port}`);
    }
  );
}

function startHttpServer(config: ServerConfig) {
  const app = express();
  const videosDir = path.resolve(__dirname, "../videos");
  const webDir = path.resolve(__dirname, "./web");

  app.use("/videos", express.static(videosDir));
  app.use("/", express.static(webDir));

  app.get("/api/videos", (req, res) => {
    try {
      const files = fs.readdirSync(videosDir).filter((f) => {
        const ext = f.toLowerCase().substring(f.lastIndexOf("."));
        return [".mp4", ".mkv", ".avi", ".webm"].includes(ext);
      });
      res.json(files);
    } catch (err) {
      console.error("Error reading videos folder:", err);
      res.status(500).json({ error: "Failed to list videos" });
    }
  });

  app.get("/api/config", (req, res) => {
    res.json(config);
  });

  app.get("/api/queue-status", (req, res) => {
    try {
      const queueLength = globalQueue.getQueueLength();
      const maxQueueLength = globalQueue.getMaxQueueLength();

      res.json({
        current_length: queueLength,
        max_length: maxQueueLength,
        videos_dropped: getDroppedCount(),
      });
    } catch (err) {
      console.error("Error getting queue status:", err);
      res.status(500).json({ error: "Failed to get queue status" });
    }
  });

  const PORT = 8080;
  app.listen(PORT, () => {
    console.log(`🌐 Web GUI running at http://localhost:${PORT}`);
  });
}

async function main() {
  const config = await getConfiguration();

  console.log("\n========================================");
  console.log("Configuration:");
  console.log(`  Consumer threads (c): ${config.c}`);
  console.log(`  Max queue length (q): ${config.q}`);
  console.log("========================================\n");

  startGrpcServer(config);
  startHttpServer(config);
}

main();
