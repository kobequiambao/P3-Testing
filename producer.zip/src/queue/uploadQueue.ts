import { Worker } from "worker_threads";
import path from "path";

interface UploadTask {
  videoBuffer: Buffer;
  filename: string;
}

export class UploadQueue {
  private queue: UploadTask[] = [];
  private workers: Worker[] = [];
  private activeWorkers = 0;

  private maxWorkers: number;
  private maxQueue: number;
  private droppedCount = 0;

  constructor(maxWorkers: number, maxQueue: number) {
    this.maxWorkers = maxWorkers;
    this.maxQueue = maxQueue;
  }

  addTask(task: UploadTask) {
    const totalLoad = this.queue.length + this.activeWorkers;

    if (totalLoad >= this.maxQueue) {
      console.warn("🗑️  Queue full — dropping video:", task.filename);
      this.droppedCount++;
      return;
    }

    this.queue.push(task);
    this.processNext();
  }

  getTotalQueueLength(): number {
    return this.queue.length + this.activeWorkers;
  }

  getQueueLength(): number {
    return this.queue.length + this.activeWorkers;
  }

  getMaxQueueLength(): number {
    return this.maxQueue;
  }

  getDroppedCount(): number {
    return this.droppedCount;
  }

  private processNext() {
    if (this.queue.length === 0 || this.activeWorkers >= this.maxWorkers)
      return;

    const task = this.queue.shift();
    if (!task) return;

    this.activeWorkers++;
    this.createWorker(task);
  }

  private createWorker(task: UploadTask) {
    const workerPath = new URL("../workers/videoWorker.js", import.meta.url);

    const worker = new Worker(workerPath);

    worker.postMessage(task);

    worker.on("message", (msg) => {
      if (msg === "done") {
        this.activeWorkers--;
        // Add delay to simulate real processing
        setTimeout(() => {
          this.processNext();
        }, 5000); // 5 second delay between processing
      } else {
        console.log("Worker message:", msg);
      }
    });

    worker.on("error", (err) => {
      console.error("Worker error:", err);
      this.activeWorkers--;
      this.processNext();
    });

    this.workers.push(worker);
  }
}
