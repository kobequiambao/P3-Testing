function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function showHoverPreview(element, filename) {
  const thumbnail = element.querySelector(".video-thumbnail");
  const video = thumbnail.querySelector(".thumbnail-video");
  const placeholder = thumbnail.querySelector(".thumbnail-placeholder");

  if (video && placeholder) {
    placeholder.style.display = "none";
    video.style.display = "block";
    video.currentTime = 0;
    video.muted = true;
    video.play().catch(() => {
      placeholder.style.display = "block";
      video.style.display = "none";
    });
  }
}

function hideHoverPreview(element) {
  const thumbnail = element.querySelector(".video-thumbnail");
  const video = thumbnail.querySelector(".thumbnail-video");
  const placeholder = thumbnail.querySelector(".thumbnail-placeholder");

  if (video && placeholder) {
    video.pause();
    video.currentTime = 0.5;
    video.style.display = "block";
    placeholder.style.display = "none";
  }
}

async function loadConfig() {
  try {
    const response = await fetch("/api/config");
    const config = await response.json();

    const configInfo = document.getElementById("configInfo");
    configInfo.innerHTML = `
      <p><strong>Configuration:</strong></p>
      <p>Consumer Threads (c): <strong>${config.c}</strong></p>
      <p>Max Queue Length (q): <strong>${config.q}</strong></p>
    `;
  } catch (err) {
    console.error("Failed to load config:", err);
  }
}

async function loadQueueStatus() {
  try {
    const response = await fetch("/api/queue-status");
    const status = await response.json();

    document.getElementById(
      "queueStatus"
    ).textContent = `${status.current_length}/${status.max_length}`;
    document.getElementById("droppedVideos").textContent =
      status.videos_dropped || 0;
  } catch (err) {
    console.error("Failed to load queue status:", err);
  }
}

async function loadVideos() {
  try {
    const response = await fetch("/api/videos");
    const videos = await response.json();

    // Always refresh UI with current videos list
    document.getElementById("totalVideos").textContent = videos.length;

    const content = document.getElementById("content");

    if (videos.length === 0) {
      content.innerHTML = `
        <div class="empty-state">
          <h2>📭 No Videos Yet</h2>
          <p>Videos uploaded by the producer will appear here</p>
        </div>
      `;
      return;
    }

    let html = '<div class="videos-grid">';

    videos.forEach((video) => {
      const filename = typeof video === "string" ? video : video.filename;

      html += `
        <div class="video-card" onmouseenter="showHoverPreview(this, '${escapeHtml(
          filename
        )}')" onmouseleave="hideHoverPreview(this)" onclick="playVideo('${escapeHtml(
        filename
      )}')">
          <div class="video-thumbnail" id="thumb-${escapeHtml(filename)}">
            <video class="thumbnail-video" style="width:100%; height:100%; object-fit:cover; display:none;">
              <source src="/videos/${encodeURIComponent(
                filename
              )}" type="video/mp4">
            </video>
            <div class="thumbnail-placeholder">🎥</div>
            <div class="preview-overlay">
              <div class="play-icon">▶</div>
            </div>
          </div>
          <div class="video-info">
            <div class="video-title" title="${escapeHtml(
              filename
            )}">${escapeHtml(filename)}</div>
            <div class="video-meta">Video File</div>
            <div class="video-actions">
              <button class="btn-play" onclick="event.stopPropagation(); playVideo('${escapeHtml(
                filename
              )}')">▶ Play</button>
            </div>
          </div>
        </div>
      `;
    });

    html += "</div>";
    content.innerHTML = html;

    // Load thumbnail video frames
    loadAllThumbnails();
  } catch (err) {
    console.error("Failed to load videos:", err);
  }
}

function loadAllThumbnails() {
  const thumbnailVideos = document.querySelectorAll(
    ".video-card .thumbnail-video"
  );
  thumbnailVideos.forEach((video) => {
    // Load first frame at 0.5 seconds
    video.currentTime = 0.5;
    video.addEventListener(
      "canplay",
      () => {
        video.style.display = "block";
        video.parentElement.querySelector(
          ".thumbnail-placeholder"
        ).style.display = "none";
      },
      { once: true }
    );
  });
}

function playVideo(filename) {
  console.log("Playing video:", filename);
  const modal = document.getElementById("videoModal");
  const video = document.getElementById("modalVideo");

  // Set video source
  video.src = `/videos/${encodeURIComponent(filename)}`;

  // Ensure video element loads
  video.load();

  // Show modal
  modal.classList.add("active");

  // Play after a short delay to ensure src is set
  setTimeout(() => {
    video.play().catch((err) => console.log("Play error:", err));
  }, 100);
}

function closeModal() {
  console.log("Closing modal");
  const modal = document.getElementById("videoModal");
  const video = document.getElementById("modalVideo");
  modal.classList.remove("active");
  video.pause();
  video.currentTime = 0;
  video.src = "";
}

// Setup modal click handler
setTimeout(function () {
  const modal = document.getElementById("videoModal");
  const modalContent = document.querySelector(".modal-content");

  if (modal) {
    modal.addEventListener("click", function (e) {
      if (e.target === modal) {
        closeModal();
      }
    });
  }

  if (modalContent) {
    modalContent.addEventListener("click", function (e) {
      e.stopPropagation();
    });
  }
}, 100);

// Load on page start
loadConfig();
loadVideos();
loadQueueStatus();

// Auto-refresh every 5 seconds
setInterval(() => {
  loadVideos();
  loadQueueStatus();
}, 5000);
